﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using CRUD_OperationsUsingDB;

namespace CRUDOperationsUsingDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into student values (@StudentID, @Name, @Father_Name, @GPA)", con);
            cmd.Parameters.AddWithValue("@StudentID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Father_Name", textBox3.Text);
            cmd.Parameters.AddWithValue("@GPA", float.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
        }
    }
}
